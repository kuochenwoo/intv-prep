# Project TODO

Updated: 2026-10-16 (Asia/Tokyo).

This list records the agreed next step and future feature ideas. Recording an item does not start its implementation. Finish AI-quality calibration before adding the deferred features below.

## Broader technical library — 2026-10-16

- [x] Add 60 bilingual P1 seeds: 180 total, with 65 foundation, 98 scenario and 17 troubleshooting openings; 146 core and 34 advanced topics across 19 categories.
- [x] Add six complete P2 scenarios: product search, configuration/flags, centralized logs, durable workflows, distributed KV and live streaming (26 total). Include local scale assumptions, authoring references and capacity examples.
- [x] Test all P1/P2 content contracts and bilingual offline caches; check the expanded native UI with computer use.
- [x] Run a bounded real P1 question-library batch: DeepSeek first, Claude fallback after an actual DeepSeek connection/TLS failure. No voice calls. Preserve original semantic failures, targeted corrections and independent review limits.
- [x] Remove answer-bearing assumptions from two legacy seeds and strengthen premise/checkpoint review rules; preserve IDs, existing cached questions and histories.
- [ ] Optional further semantic refinement: diagnose why a model can still require one particular hypothesis or an unasked boundary after passing its own reviewer. Do not count such samples as human-accepted.
- [ ] Real multi-stage acceptance for the six newest P2 scenarios; current coverage is content, offline persistence, native selection and regression only.

See [coverage and acceptance](docs/LIBRARY_EXPANSION_2026-10-16.md). Previous batches below retain their original scope and counts. Future test defaults: no voice; DeepSeek for text, Claude on DeepSeek API failure; OpenAI remains voice-only.

## Completed baseline

- [x] P0: project setup and real local C++20 judging in Function and ACM modes.
- [x] P1: streamed Technical Deep Dive interviews, reference answers, five-dimension feedback, caching and recovery; 40 bilingual topic seeds.
- [x] P2: five user-controlled interview stages, capacity estimates, architecture notes/Mermaid, eight-dimension feedback, caching and recovery; 15 bilingual scenario seeds.
- [x] LeetCode Hot 100 coverage with complexity metadata, enforced local resource budgets and reference solutions verified in both modes.
- [x] Reliability follow-up and reading-focused UI typography adjustments.

These completed workflows do not imply that every model-generated question or judgement is correct.

## Practical P1/P2 content update (2026-10-16)

- [x] Develop 120 bilingual P1 topics (40 foundation, 68 scenario, 12 troubleshooting) with local core/further-practice priorities, source records and sidebar filters.
- [x] Replace Java-only seed assumptions with explicit language-neutral technical contracts while preserving IDs.
- [x] Adapt opening, follow-up and review policies for natural technical questions; keep answer propositions private and feedback evidence-based.
- [x] Add five complete P2 scenarios (20 total): orders/payment expiration, leaderboards, identity/sessions, wallets/withdrawals and visitor analytics. Document matching P1 prerequisites.
- [x] Correct overly leading diagnostic openings: neutral cache topic title, one-incident evidence-first questions, private diagnosis labels and matching reviewer rules.
- [x] Update existing automated test definitions for the changed content and compatibility contracts.
- [x] Fix unasked-boundary downgrades in foundation feedback and recheck the same real B+ tree answer: demonstrated dimensions good, unassessed dimensions missing, no gaps.
- [x] Run affected automated tests and frontend/native builds after the user authorized P1 acceptance: 92 backend + 11 frontend passed, 1 intentionally ignored Keychain test.
- [x] Perform bilingual P1 native UI/UX acceptance and representative DeepSeek text review: 49 actual HTTP attempts, with original failures, approved retries and semantic limits recorded. Fix stale topic/session ownership and support Markdown code throughout P1.
- [ ] Separately authorize and perform live acceptance of the five new P2 scenarios; P2 content/shared regression passed but those live scenarios were outside this P1 test.
- [ ] Optional further AI wording refinement: cache-diagnostics feedback can overstate missing verification detail even when sampling was proposed. Do not equate this residual with a failure of local storage/recovery.

See [implementation scope and module mapping](docs/P1_PRACTICAL_FUNDAMENTALS.md) and [P1 acceptance](docs/P1_ACCEPTANCE_2026-10-16.md). The 40/15-topic entries above and the calibration report below describe the previously accepted baseline.

## AI calibration: completed for the agreed Claude baseline

- [x] Improve P1 question generation: assess one core mechanism in a concrete scenario, avoid giving away the answer in visible constraints, and keep optional extensions out of mandatory opening-question criteria.
- [x] Improve follow-ups in both modules: respond to the actual answer, acknowledge what is already explained, avoid repetitive demands, and explicitly identify changed assumptions. Keep P1 at mechanism/local-boundary depth and P2 at its selected architecture stage.
- [x] Improve evidence-based feedback: do not count unasked material or unanswered interviewer questions as demonstrated weaknesses. Accept equivalent explanations rather than requiring keywords or a prescribed phrasing.
- [x] Reliably exclude AI-assisted answers from evidence of independent understanding. AI-only evidence must not receive independent-ability credit; disclose assistance and use `missing` for dimensions with no independent evidence.
- [x] Calibrate P2 estimates: recognize explicitly stated illustrative or alternative assumptions, distinguish them from task defaults, verify formulas/units, and explain when task figures should be substituted. Do not invent benchmark results or demand unsupported precision.
- [x] Calibrate P2 architecture feedback: accept defensible alternatives, evaluate end-to-end data flow and cross-component trade-offs, and distinguish genuine contradictions from an interviewer silently changing the failure window.
- [x] Build regression samples from new P1 topics and P2 scenarios using correct, partially correct, incorrect and "I do not know" answers. Include AI-assisted and mixed independent/assisted histories, bilingual cases and the failures already observed in live probes.
- [x] Add necessary automated checks and review real-provider samples. Record provider/model, input assumptions, expected behavior and observed defects. Report transport/schema success separately from semantic-quality acceptance; never mock a successful live request or judgement.

The earlier DeepSeek batches remain historical evidence. Claude Haiku 5.5 closeout now has **11 human-reviewed positive question/feedback outputs, three rejected adversarial probes, and a separately verified epoll prerequisite follow-up**; the final affected test suite passed 54 checks, with one intentionally ignored Keychain round-trip. The earlier broader suite passed 74 checks. Failed attempts, scope corrections and final real-provider verdicts are preserved under `review/`.

Closeout work:

- [x] Strict generation-only answer terms, legacy cache compatibility and semantic review for synonymous hints/checklist scope.
- [x] Summaries derived from real ratings, independent/assisted counts and actual P2 stages; `missing` means insufficient independent evidence, not necessarily an unasked question or an error.
- [x] Preserve evidence supplied in any stage; check actual gap relevance rather than trusting a question citation.
- [x] Dedicated question/feedback review roles and bounded repair carrying the exact prior proposal plus critique; rejected/failed requests remain failures.
- [x] Final Claude live acceptance, including cross-stage reasoning, AI-assisted/mixed histories and adversarial hints, irrelevant gaps and uncertain-versus-missing probes.

See [calibration report](docs/AI_QUALITY_CALIBRATION.md) and [acceptance manifest](review/calibration-closeout-acceptance.json). This completes the agreed scripted baseline; it does not guarantee all future model judgements. Model review adds latency/API usage and can still reject valid content or miss defects. New policies do not rewrite old histories; final-policy DeepSeek semantics were not revalidated in this Claude-only closeout. The user subsequently authorized exports, hint/scope cleanup, timed interviews and API accounting; see the completed entries below.

Existing evidence and defects:

- [P1 content expansion and live review](docs/P1_CONTENT_EXPANSION.md): visible answer leakage, optional checklist scope, AI-assisted ratings, and unasked material listed as gaps.
- [P2 content expansion and live review](docs/P2_CONTENT_EXPANSION.md): mischaracterized illustrative estimates, unsupported compression assumptions, and follow-ups that revisit a failure window already excluded by the answer.
- [Reliability follow-up](docs/RELIABILITY_2026-10-15.md): real-provider workflow acceptance and its limits.

## Deferred features, in suggested order

### 1. Voice answers with editable transcription — core implementation validated

- [x] Implement speech input during P1 and P2 interviews using OpenAI `gpt-4o-mini-transcribe`.
- [x] Show an editable transcript and let the user correct recognition mistakes before submission.
- [x] Submit only after explicit user action, through the existing answer/follow-up workflow.
- [x] Validate the core voice path: builds, 91 automated checks, native microphone/UI checks and three real OpenAI transcriptions.

Live text checks used DeepSeek only: P1 generation/follow-up/feedback and P2 follow-up passed. P2 feedback hit a connection/TLS failure and remains pending in the isolated test ledger; that batch is not a full DeepSeek acceptance pass. Broader accent/device, explicit permission-denial and full five-minute/size-limit UI testing remain outside this core acceptance.

The OpenAI key is for voice input only. Interview generation and feedback remain on Claude/DeepSeek. See [voice input](docs/VOICE_INPUT.md) for operation, accounting limits and pending acceptance.

### 2. Review and weak-point tracking — completed

- [x] Summarize recurring mistakes, concepts to revisit and related exercises across interview history.
- [x] Link each finding to the actual answer/feedback evidence and keep independent answers distinct from AI assistance.

### 3. Study plans and spaced review — completed

- [x] Turn weak points and past practice into a manageable review queue.
- [x] Schedule spaced revisits and track whether previously weak concepts have improved.

Review acceptance now includes unassessed/AI-only evidence filtering, exact feedback provenance, guarded P1/P2 navigation and unknown-cost regression checks. See [Review tab](docs/REVIEW.md). Completed follow-ups: P1/P2 feedback shows an "Added to Review" note; LeetCode countdowns persist per problem and contribute elapsed time to Review, including archived attempts after reset.

### 4. Timed mock interviews — completed

- [x] Add timed practice to P1/P2, combining answers, follow-ups and a final review into an interview session.
- [x] Make the time budget and progress visible while preserving drafts and existing recovery behavior.

### 5. API usage and cost records — completed

- [x] Record usage for question generation, follow-ups, reference answers and feedback by provider/model and interview.
- [x] Show provider-reported token usage where available; distinguish cost estimates from billed amounts and unknown usage from zero usage.
- [x] Keep credentials out of usage records and exports.

### 6. Interview exports — completed

- [x] Export questions, answers, follow-ups and feedback for later review.
- [x] Include P2 design notes and diagram source, and preserve language and AI-assistance labels.
- [x] Export Markdown for reading and versioned JSON for structured review; include saved notes, diagram source, assistance labels, timing and session usage, and omit drafts/private checkpoints.

### 7. Remove question hints and out-of-scope checkpoints — completed

- [x] Preserve strict new-question answer-term checks and bounded semantic review for synonymous hints and opening-question scope.
- [x] Remove P1 seed focus/extension lists and P2 deep-dive directions from visible preparation panels; narrow the P1 answer placeholder to the current question.
- [x] Keep private checklists/directions out of streamed candidate text, feedback evidence and exports; withhold new-question previews until validation/review completes. Legacy histories remain unchanged rather than being silently rewritten.

See [session tools delivery](docs/SESSION_TOOLS.md) for behavior, validation and limits. Timers default to off, offer 10/20/30 minutes, and require an explicit Start. API estimates require explicit local rates and are not invoices; old usage is not backfilled.

## Implementation constraints

Keep project documentation/comments in English, UI strings bilingual, and Astryx styling consistent. Preserve existing histories, drafts and LC complexity/resource policies. Keys remain provider-specific in the Git-ignored `.env` with mode `0600`; do not migrate to Keychain as part of these backlog items without the separately agreed migration step. Real API checks require intentional provider usage and honest reporting of failures and quality limitations.
